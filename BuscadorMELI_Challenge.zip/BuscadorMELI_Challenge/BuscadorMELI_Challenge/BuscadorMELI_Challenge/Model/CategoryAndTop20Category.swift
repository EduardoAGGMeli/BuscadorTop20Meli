//
//  CategoryAndTop20Category.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 3/04/22.
//

import Foundation

struct Category: Decodable {
    let domainName: String
    let categoryId: String
    
    private enum CodingKeys: String, CodingKey {
        case domainName = "domain_name"
        case categoryId = "category_id"
    }
}

struct Top20Wrapper: Decodable {
    let content: [Top20Category]
}

struct Top20Category: Decodable {
    let id: String
    let position: Int
    let type: String
}

struct MultiGet: Decodable {
    let body: InfoBody
}

struct InfoBody: Decodable {
    let title: String
    let price: Double
    let id: String
}

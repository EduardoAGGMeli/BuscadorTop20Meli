//
//  UIImageViewExtension.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 4/04/22.
//

import Foundation
import Kingfisher

extension UIImageView {
    
    func setImageFrom(url: String) {
        let url = URL(string: url)
        let scale = UIScreen.main.scale
        self.kf.indicatorType = .activity
        self.kf.setImage(
            with: url,
            options: [
                .scaleFactor(scale),
                .transition(.fade(1)),
            ])
    }
    
}

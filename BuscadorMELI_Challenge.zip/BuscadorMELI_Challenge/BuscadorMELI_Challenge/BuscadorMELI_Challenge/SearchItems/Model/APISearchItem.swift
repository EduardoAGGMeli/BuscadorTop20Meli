//
//  APISearchItem.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 31/03/22.
//

import Foundation

struct APISearchItem: Decodable {
    
    enum Condition: String {
        case new = "Nuevo"
        case used = "Usado"
    }
    
    var id: String
    var title: String
    //let seller: Seller
    var price: Double
    var availableQuantity: Int
    var soldQuantity: Int
    var condition: String
    var thumbnail: String
    var acceptsMercadopago: Bool
    //let installments: Installments
    var address: ItemAddress
    var shipping: Shipping
    
    private enum CodingKeys: String, CodingKey {
        case id
        case title
        //case seller
        case price
        case availableQuantity = "available_quantity"
        case soldQuantity = "sold_quantity"
        case condition
        case thumbnail
        case acceptsMercadopago = "accepts_mercadopago"
        //case installments
        case address = "seller_address"
        case shipping
    }
    
    
    
    
    
    private func getTextIfItsFreeShipping(shipping: Shipping) -> String {
        return shipping.freeShipping ? "Envío gratis" : ""
    }

    
}

struct Seller: Decodable {
    let id: Double
}

struct Installments: Decodable {
    let quantity: Int
    let amount: Double
}

struct ItemAddress: Decodable {
    let state: StateName
    let city: CityName
}

struct StateName: Decodable {
    let name: String
}

struct CityName: Decodable {
    let name: String
}

struct Shipping: Decodable {
    let freeShipping: Bool
    let storePickup: Bool
    
    private enum CodingKeys: String, CodingKey {
        case freeShipping = "free_shipping"
        case storePickup = "store_pick_up"
    }
}



//
//  SearchItemsVC.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 30/03/22.
//

import UIKit

class SearchItemsVC: UITableViewController {
    
    private let searchController = UISearchController()
    private let navigationTitle = "Inicio"
    private let searchBarPlaceholder = "Buscar en Mercado Libre"
    private let service: SearchCategoryProtocol = SearchCategoryService()
    private var top20: [Top20Category] = []
    private var arrayTop20: [MultiGet] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
        setupSearchController()
        

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupNavigationBar()
    }
    
    private func setupNavigationBar() {
        navigationItem.title = navigationTitle
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .systemYellow
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }
    
    private func setupSearchController () {
        searchController.searchBar.delegate = self
        
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = searchBarPlaceholder
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }
    
    private func setUpTableView() {
        let nib = UINib(nibName: SearchItemTableViewCell.reusableIdentifier, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: SearchItemTableViewCell.reusableIdentifier)
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 80
        
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayTop20.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SearchItemTableViewCell.reusableIdentifier, for: indexPath) as? SearchItemTableViewCell else {
            return UITableViewCell()
        }
        let currentItem = arrayTop20[indexPath.row].body
        cell.setUpCell(nameItem: currentItem.title, price: currentItem.price)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentItem = arrayTop20[indexPath.row]
        let vc = ItemDetailVC(id: currentItem.body.id)
        navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

extension SearchItemsVC: UISearchBarDelegate {
    
    // func called when a user press the search button in the keyboard.
    // execute the request to search items if there's text in the searchBar
    private func executeSearch(text: String) {
        service.getSearchedCategory(params: text) { [weak self] result in
            switch result {
            case .success(let categories):
                guard !categories.isEmpty else {
                    print("No se encontraron coincidencias")
                    DispatchQueue.main.async {
                        self?.showSimpleAlert()
                    }
                    return
                }
                let categoryId = categories[0].categoryId
                self?.service.getSearchedTop20(categoryID: categoryId, completion: { [weak self] result in
                    guard let self = self else { return }
                    switch result {
                    case .success(let top20):
                        self.top20 = top20.content
                        
                        print(top20)
                    case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                            self.showSimpleAlertTop20()
                        }
                    }
                    let top20Ids = self.top20.map({$0.id})
                    print(top20Ids)
                    self.service.getTop20Details(top20Ids: top20Ids, completion: { [weak self] result in
                        guard let self = self else { return }
                        switch result {
                        case .success(let arrayTop20):
                            self.arrayTop20 = arrayTop20
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                            }
                        case .failure(let error):
                            print(error)
                            DispatchQueue.main.async {
                                self.showSimpleAlertTop20()
                            }
                        }
                    })
                })
                
                print(categories)
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if let searchText = searchBar.text {
            executeSearch(text: searchText)
        }
    }
    
    func showSimpleAlert() {
        let alert = UIAlertController(title: "No se ha encontrado", message: "No existe un Top20 para esta categoria",         preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            //Cancel Action
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showSimpleAlertTop20() {
        let alert = UIAlertController(title: "No se ha encontrado", message: "No se ha logrado asociar la busquedad con una categoria",         preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            //Cancel Action
        }))
        self.present(alert, animated: true, completion: nil)
    }
}

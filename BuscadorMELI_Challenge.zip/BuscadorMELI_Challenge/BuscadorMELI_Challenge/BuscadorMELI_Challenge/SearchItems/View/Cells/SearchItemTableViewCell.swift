//
//  SearchItemTableViewCell.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 30/03/22.
//

import UIKit

class SearchItemTableViewCell: UITableViewCell {

    static let reusableIdentifier = String(describing: SearchItemTableViewCell.self)

    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var positionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    func setUpCell(nameItem: String, price: Double) {
        itemNameLabel.text = nameItem
        positionLabel.text = formatPriceWithCountryCurrency(value: price)
    }
    
    private func formatPriceWithCountryCurrency(value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = "$"
        formatter.locale = Locale(identifier: "es_CO")
        
        return formatter.string(from: value as NSNumber) ?? ""
    }
}

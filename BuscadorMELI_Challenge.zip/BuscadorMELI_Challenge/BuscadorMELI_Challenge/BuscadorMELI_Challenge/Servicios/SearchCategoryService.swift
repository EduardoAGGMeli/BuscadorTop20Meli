//
//  SearchCategoryService.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 2/04/22.
//

import Foundation

protocol SearchCategoryProtocol {
    func getSearchedCategory(params: String, completion: @escaping (Result<[Category], NetworkError>) -> Void)
    func getSearchedTop20(categoryID: String, completion: @escaping (Result<Top20Wrapper, NetworkError>) -> Void)
    func getItemDetails(id: String, completion: @escaping (Result<APISearchItem, NetworkError>) -> Void)
    func getTop20Details(top20Ids: [String], completion: @escaping (Result<[MultiGet], NetworkError>) -> Void)
}

final class SearchCategoryService: BaseNetwork, SearchCategoryProtocol {
   
    func getSearchedCategory(params: String, completion: @escaping (Result<[Category], NetworkError>) -> Void) {
        let endpoint = NetworkConstants.searchCategory + params
        
        sendRequest(endpoint, of: [Category].self, completion: completion)
    }
    
    func getSearchedTop20(categoryID: String, completion: @escaping (Result<Top20Wrapper, NetworkError>) -> Void) {
        let endpoint = NetworkConstants.searchTop20Category + categoryID
        
        sendRequest(endpoint, of: Top20Wrapper.self, completion: completion)
    }
    
    func getItemDetails(id: String, completion: @escaping (Result<APISearchItem, NetworkError>) -> Void) {
        let endpoint = NetworkConstants.searchProductDetail + id
        
        sendRequest(endpoint, of: APISearchItem.self, completion: completion)
    }
    
    func getTop20Details(top20Ids: [String], completion: @escaping (Result<[MultiGet], NetworkError>) -> Void) {
        let ids = "\(top20Ids[0]),\(top20Ids[1]),\(top20Ids[2]),\(top20Ids[3]),\(top20Ids[4]),\(top20Ids[5]),\(top20Ids[6]),\(top20Ids[7]),\(top20Ids[8]),\(top20Ids[9]),\(top20Ids[10])"
        let endpoint = NetworkConstants.searchMultiGet + ids
        
        sendRequest(endpoint, of: [MultiGet].self, completion: completion)
    }
}


//
//  NetworkConstans.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 1/04/22.
//

import Foundation

struct NetworkConstants {
    static let baseURL = "https://api.mercadolibre.com"
    static let searchCategory = "/sites/MCO/domain_discovery/search?limit=1&q="
    static let searchTop20Category = "/highlights/MCO/category/"
    static let searchMultiGet = "/items?ids="
    static let searchProductDetail = "/items/"
}


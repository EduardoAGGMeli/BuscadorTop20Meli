//
//  NetworkServices.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 1/04/22.
//

import Foundation
import Alamofire

class BaseNetwork {
    
    let headers: HTTPHeaders = [
        .authorization(bearerToken: "APP_USR-6209135293055396-040517-577fdc0093664fe106de2a4fd00a6e39-789151578" )
    ]
    
    func sendRequest<T: Decodable>(_ endpoint: String, of: T.Type, completion: @escaping (Result<T, NetworkError>) -> Void) {
        let requestURL = NetworkConstants.baseURL + endpoint
        
        AF.request(requestURL, method: .get,  headers: headers )
            .validate(statusCode: 200..<300)
            .responseDecodable(of: T.self, queue: .global(qos: .background)) { response in
                let result = response.result
                switch result {
                case .success(let object):
                    completion(.success(object))
                case .failure(let error):
                    if error.isInvalidURLError {
                        completion(.failure(.invalidURL))
                        print("..::Invalid URL or query param::.. \n \(error)")
                        break
                    }
                    if error.isResponseSerializationError {
                        completion(.failure(.parsingData))
                        print("..::Error while parsing data::.. \n \(error)")
                        break
                    }
                    print("..::Any other error::.. \n \(error)")
                }
            }
    }
}

//
//  NetworkError.swift
//  BuscadorMELI_Challenge
//
//  Created by Eduardo Alfonso Gutierrez Gomez on 1/04/22.
//

import Foundation

enum NetworkError: String, Error {
    case genericError = "Generic Error"
    case parsingData = "Parsing Error"
    case invalidURL = "Invalid URL"
    case reachability = "No internet conection detected"
}
